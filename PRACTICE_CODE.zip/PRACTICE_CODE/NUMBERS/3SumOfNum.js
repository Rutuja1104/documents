const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
rl.question("Enter the number ", (answer) => {
  let a = 0;
  let n = parseInt(answer);
  for (let index = 0; index <= n; index++) {
    a = a + index;
  }
  console.log("SUM :", a);
  rl.close();
});
