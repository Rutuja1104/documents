const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
rl.question("Enter the number ", (answer) => {
  if (answer % 2 === 0) {
    console.log("EVEN NUMBER");
  } else if (answer % 2 !== 0) {
    console.log("ODD NUMBER");
  } else {
    console.log("INVALID");
  }
  rl.close();
});
