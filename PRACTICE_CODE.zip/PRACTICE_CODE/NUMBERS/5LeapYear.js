const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Enter Year : ", (ans) => {
  if (ans % 4 == 0) {
    console.log(`${ans} LEAP YEAR`);
  } else {
    console.log(`${ans} NOT LEAP YEAR`);
  }
  rl.close();
});
