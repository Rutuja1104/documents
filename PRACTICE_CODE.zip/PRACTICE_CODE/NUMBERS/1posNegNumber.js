const readline = require("readline");
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
rl.question("Enter the number ", (answer) => {
  if (answer > 0) {
    console.log("POSITIVE");
  } else if (answer < 0) {
    console.log("NEGATIVE");
  } else if (answer == 0) {
    console.log("0 is neither positive nor negative");
  } else {
    console.log("INVALID");
  }
  rl.close();
});
