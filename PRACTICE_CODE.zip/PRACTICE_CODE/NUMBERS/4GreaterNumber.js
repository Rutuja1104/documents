const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("Enter the first number: ", (num1) => {
  rl.question("Enter the second number: ", (num2) => {
    const parsedNum1 = parseFloat(num1.trim());
    const parsedNum2 = parseFloat(num2.trim());

    if (isNaN(parsedNum1) || isNaN(parsedNum2)) {
      console.log("Please enter valid numbers.");
    } else {
      // const sum = parsedNum1 + parsedNum2;
      // console.log(`The sum of ${parsedNum1} and ${parsedNum2} is ${sum}`);
      parsedNum1 > parsedNum2
        ? console.log(`Greater ${parsedNum1} `)
        : console.log(`Greater ${parsedNum2} `);
    }

    rl.close();
  });
});
