const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

rl.question("ENTER THE NUMBER : ", (ans) => {
  let c = 0;
  for (let index = 2; index < array.length; index++) {
    const element = array[index];
  }
  rl.close();
});
