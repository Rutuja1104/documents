const LargestElement = (arr) =>{
 return arr.sort((a,b)=>b-a)[0]
}
console.log(LargestElement([11,256,2,3,3,45,56,67,90]));