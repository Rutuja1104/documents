const SmallestElement = (arr) =>{
    return arr.sort((a,b)=>a-b)[0]
   }
console.log(SmallestElement([11,256,2,3,3,45,56,67,90]));